﻿using model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace networking.objectProtocol
{
    [Serializable]
    public class Request
    {

    }

    [Serializable]
    public class LoginRequestAgent : Request
    {
        public string data { get; set; }
        public string password { get; set; }

        public string job { get; set; }

        public LoginRequestAgent(string data, string password, string job)
        {
            this.data = data;
            this.password = password;
            this.job = job; 
        }
    }

    [Serializable]
    public class LoginRequestManager : Request
    {
        public string data { get; set; }
        public string password { get; set; }

        public string job { get; set; }

        public LoginRequestManager(string data, string password, string job)
        {
            this.data = data;
            this.password = password;
            this.job = job;
        }
    }

    [Serializable]
    public class AllProduseRequest : Request
    {

    }

    [Serializable]
    public class AddInCosRequest : Request
    {

    }

   /* [Serializable]
    public class AddRequest : Request
    {
        public Produs produs { get; set; }

        public AddRequest(Produs produs)
        {
            this.produs = produs;
        }
    }

    [Serializable]
    public class DeleteRequest : Request
    {
        public long id { get; set; }

        public DeleteRequest(long id)
        {
            this.id = id;
        }
    }

    [Serializable]
    public class UpdateRequest : Request
    {
        public long id { get; set; }
        public string denumire { get; set; }
        public int pret { get; set; }
        public int cantitate { get; set; }

        public UpdateRequest(long id, string denumire, int pret, int cantitate)
        {
            this.id = id;
            this.denumire = denumire;
            this.pret = pret;
            this.cantitate = cantitate;
        }
    }*/



}
