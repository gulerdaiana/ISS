﻿using model;
using networking.objectProtocol;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace networking.objectProtocol
{
    [Serializable]
    public class Response
    {

    }

    [Serializable]
    public class OkResponse : Response
    {

    }

    [Serializable]
    public class ErrorResponse : Response
    {
        public string message { get; set; }

        public ErrorResponse(string message)
        {
            this.message = message;
        }

    }

    [Serializable]
    public class LoggedInResponseAgent : OkResponse
    {
        public Agent a { get; set; }

        public LoggedInResponseAgent(Agent a)
        {
            this.a = a;
        }

    }

    [Serializable]
    public class LoggedInResponseManager : OkResponse
    {
        public Manager m { get; set; }

        public LoggedInResponseManager(Manager m)
        {
            this.m = m;
        }

    }

    [Serializable]
    public class AllProduseResponse : OkResponse
    {
        public IEnumerable<Produs> produse { get; set; }

        public AllProduseResponse(IEnumerable<Produs> produse)
        {
            this.produse = produse;
        }
    }
}
    /* [Serializable]
    public class UpdateResponse : Response
    {
         public Produs updatedProdus { get; set; }

         public UpdateResponse(Produs updatedProdus)
         {
             this.updatedProdus = updatedProdus;
             
         } 
    }

    [Serializable]
    public class AddResponse : Response
    {
        public Produs addedProdus { get; set; }

        public AddResponse(Produs addedProdus)
        {
            this.addedProdus = addedProdus;
        }
    }
}

    [Serializable]
    public class DeleteResponse : Response
    {
       
    }*/

