﻿using log4net.Repository.Hierarchy;
using model;
using services;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Sockets;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace networking.objectProtocol
{
    public class ClientObjectWorker : IObserver 
    {

        private IService server;
        private TcpClient connection;

        private NetworkStream stream;
        private IFormatter formatter;
        private volatile bool connected;

        public ClientObjectWorker(IService server, TcpClient connection)
        {
            this.server=server;
            this.connection=connection;
            try
            {
                stream = connection.GetStream();
                formatter = new BinaryFormatter();
                connected = true;

            }catch (Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
            }
        }

        public void ProdusAdaugat(IEnumerable<Produs> all,Produs p)
        {
            throw new NotImplementedException();
        }
        

        public virtual void run()
        {
            while (connected)
            {
                try
                {
                    stream.Flush();
                    object request = formatter.Deserialize(stream);
                    object response = handleRequest((Request)request);
                    if(response != null)
                    {
                        sendResponse((Response)response);
                    }
                }catch (Exception ex)
                {
                    Console.WriteLine(ex.StackTrace);
                }

                try
                {
                    Thread.Sleep(1000);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.StackTrace);
                }
            }

            try
            {
                stream.Close();
                connection.Close();
            }catch (Exception ex)
            {
                Console.WriteLine("ERROR " + ex);
            }
        }

        private Response handleRequest(Request request)
        {
            Response response = null;
            Console.WriteLine("Am primit request");
            if(request is LoginRequestAgent)
            {
                Console.WriteLine("LOGIN REQUEST..");
                LoginRequestAgent logReq = (LoginRequestAgent)request;
                Console.WriteLine(logReq.data);
               
                try
                {
                    Agent a = null;
                    lock (server)
                    {
                        a = server.loginAgent(logReq.data, logReq.password,logReq.job, this);
                    }
                    response = new LoggedInResponseAgent(a);
                }catch(Exception ex)
                {
                    connected = false;
                    return new ErrorResponse(ex.Message);
                }
            }
            if (request is LoginRequestManager)
            {
                Console.WriteLine("LOGIN REQUEST..");
                LoginRequestManager logReq = (LoginRequestManager)request;
                Console.WriteLine(logReq.data);
                try
                {
                    Manager m = null;
                    lock (server)
                    {
                        m = server.loginManager(logReq.data, logReq.password,logReq.job, this);
                    }
                    response = new LoggedInResponseManager(m);
                }
                catch (Exception ex)
                {
                    connected = false;
                    return new ErrorResponse(ex.Message);
                }
            }
            if (request is AllProduseRequest)
            {
                Console.WriteLine("GET ALL REQUEST..");
                AllProduseRequest req = (AllProduseRequest)request;
                try
                {
                    lock (server)
                    {
                        response = new AllProduseResponse(server.getAllProduse());
                    }
                }catch(Exception ex)
                {
                    connected = false;
                    return new ErrorResponse(ex.Message);
                }

            }
            /*if(request is AddRequest)
            {
                Console.WriteLine("ADD REQUEST...");
                AddRequest req = (AddRequest)request;
                try
                {
                    Produs p = new Produs(req.produs.Id,req.produs.denumire,req.produs.pret,req.produs.cantitate);
                    lock (server)
                    {
                        server.add(p);
                    }
                    response = new AddResponse(p);
                }
                catch (Exception ex)
                {
                    connected = false;
                    return new ErrorResponse(ex.Message);
                }
            }
            if (request is DeleteRequest)
            {
                Console.WriteLine("DELETE REQUEST...");
                DeleteRequest req = (DeleteRequest)request;
                try
                {
                    lock (server)
                    {
                        server.delete(req.id);
                    }
                    response = new DeleteResponse();
                }
                catch (Exception ex)
                {
                    connected = false;
                    return new ErrorResponse(ex.Message);
                }
            }
            if (request is UpdateRequest)
            {
                Console.WriteLine("UPDATE REQUEST...");
                UpdateRequest req = (UpdateRequest)request;
                try
                {
                    //Produs p = null;
                    //Produs p = new Produs(req.id, req.denumire, req.pret, req.cantitate);
                    lock (server)
                    {
                        p=server.update(req.id, req.denumire, req.pret, req.cantitate);
                    }
                    response = new UpdateResponse(p);
                }
                
                catch (Exception ex)
                {
                    connected = false;
                    return new ErrorResponse(ex.Message);
                }
            }*/


            Console.WriteLine(response.ToString());
            return response;
        }

        private void sendResponse(Response response)
        {
            Console.WriteLine("Sending response : " + response);
            lock (stream)
            {
                formatter.Serialize(stream, response);
                stream.Flush();
            }
           
        }

    }
}
