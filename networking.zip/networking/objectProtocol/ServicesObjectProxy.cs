﻿using model;
using services;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Sockets;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace networking.objectProtocol
{
    public class ServicesObjectProxy : IService
    {

        private string host;
        private int port;

        private IObserver client;
        private NetworkStream stream;

        private IFormatter formatter;
        private TcpClient connection;

        private Queue<Response> responseQueue;
        private volatile bool finished;
        private EventWaitHandle _waitHandle;

        public ServicesObjectProxy(string host, int port)
        {
            this.host=host;
            this.port=port;
            responseQueue = new Queue<Response>();
        }

        public Agent loginAgent(string data, string password,string job, IObserver client)
        {
            initializeConnection();
            Debug.WriteLine("initializeConnection() done");
            Debug.WriteLine(data);
            Debug.WriteLine(password);
            Debug.WriteLine(job);

            sendRequest(new LoginRequestAgent(data, password,job));

            Debug.WriteLine("Request sent");
            Response response = readResponse();
            Debug.WriteLine("Response received");
            if(response is LoggedInResponseAgent)
            {
                this.client = client;
                return ((LoggedInResponseAgent)response).a;
            }
            if(response is ErrorResponse)
            {
                ErrorResponse errorResponse = (ErrorResponse)response;
                closeConnection();
                throw new Exception(errorResponse.message);
            }
            return null;
        }
        public Manager loginManager(string data, string password, string job, IObserver client)
        {
            initializeConnection();
            Debug.WriteLine("initializeConnection() done");
            Debug.WriteLine(data);
            Debug.WriteLine(password);
            Debug.WriteLine(job);

            sendRequest(new LoginRequestManager(data, password, job));

            Debug.WriteLine("Request sent");
            Response response = readResponse();
            Debug.WriteLine("Response received");
            if (response is LoggedInResponseManager)
            {
                this.client = client;
                return ((LoggedInResponseManager)response).m;
            }
            if (response is ErrorResponse)
            {
                ErrorResponse errorResponse = (ErrorResponse)response;
                closeConnection();
                throw new Exception(errorResponse.message);
            }
            return null;
        }

        private void sendRequest(Request request)
        {
            try
            {
                formatter.Serialize(stream, request);
                stream.Flush();
            }
            catch (Exception e)
            {
                throw new Exception("Error sending object "+e);
            }

        }

        private Response readResponse()
        {
            Response response = null;
            try
            {
                _waitHandle.WaitOne();
                lock (responseQueue)
                {
                 
                    response = responseQueue.Dequeue();

                }


            }
            catch (Exception e)
            {
                Debug.WriteLine(e.StackTrace);
            }
            return response;
        }

        private void closeConnection()
        {
            finished=true;
            try
            {
                stream.Close();

                connection.Close();
                _waitHandle.Close();
                client=null;
            }
            catch (Exception e)
            {
                Debug.WriteLine(e.StackTrace);
            }

        }

        private void initializeConnection()
        {
            try
            {
                connection=new TcpClient(host, port);
                stream=connection.GetStream();
                Debug.WriteLine(stream.ToString());
                formatter = new BinaryFormatter();
                finished=false;
                _waitHandle = new AutoResetEvent(false);
                startReader();
            }
            catch (Exception e)
            {
                Debug.WriteLine(e.Message);
            }
        }
        private void startReader()
        {
            Thread tw = new Thread(run);
            tw.Start();
        }

        

        public void run()
        {
            while (!finished)
            {
                try
                {
                    stream.Flush();
                    object response = formatter.Deserialize(stream);
                    Debug.WriteLine(response.ToString());

                    
                        lock (responseQueue)
                        {
                            responseQueue.Enqueue((Response)response);
                        }
                        _waitHandle.Set();
                    
                }
                catch (Exception e)
                {
                    Debug.WriteLine("reading error[proxy RUN] " + e.Message);
                }
            }
        }

        public IEnumerable<Produs> getAllProduse()
        {
            sendRequest(new AllProduseRequest());
            Response response = readResponse();
            if (response is AllProduseResponse)
            {
                return ((AllProduseResponse)response).produse;
            }
            if (response is ErrorResponse)
            {
                ErrorResponse errorResponse = (ErrorResponse)response;
                closeConnection();
                throw new Exception(errorResponse.message);
            }
            return null;
        }

        public void add(Produs p)
        {
            /*sendRequest(new AddRequest(p));
            Response response = readResponse();
            if (response is OkResponse)
            {
                return;
            }
            if (response is ErrorResponse)
            {
                ErrorResponse errorResponse = (ErrorResponse)response;
                closeConnection();
                throw new Exception(errorResponse.message);
            }*/
            throw new NotImplementedException();    
        }
        public void delete(long id)
        {
            /*sendRequest(new DeleteRequest(id));
            Response response = readResponse();
            if(response is OkResponse)
            {
                return;
            }
            if (response is ErrorResponse)
            {
                ErrorResponse errorResponse = (ErrorResponse)response;
                closeConnection();
                throw new Exception(errorResponse.message);
            }*/
            throw new NotImplementedException();
        }

        public void update(long id,string denumire, int pret, int cantitate)
        {
            /*sendRequest(new UpdateRequest(id,denumire,pret,cantitate));
            Response response = readResponse();
            if (response is OkResponse)
            {
                return;
            }
            if (response is ErrorResponse)
            {
                ErrorResponse errorResponse = (ErrorResponse)response;
                closeConnection();
                throw new Exception(errorResponse.message);
            }*/
            throw new NotImplementedException();
        }
        public Agent findOneAgent(string username)
        {
            throw new NotImplementedException();
        }

        public Manager findOneManager(string username)
        {
            throw new NotImplementedException();
        }

        public Produs findOneProdus(long id)
        {
            throw new NotImplementedException();
        }

        public void addInCos(Cos c)
        {
            throw new NotImplementedException();

        }

    }
}
