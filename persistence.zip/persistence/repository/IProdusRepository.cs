﻿using model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace persistence.repository
{
    public interface IProdusRepository : IRepository<long, Produs>
    {
        void add(Produs produs);
        void delete(long id);
        void update(long id, string denumire,int pret, int cantitate);
    }
}
