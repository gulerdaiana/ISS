﻿using model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace persistence.repository
{
    public interface IRepository<ID, E> where E : Entity<ID>
    {
        void add(E entity);

        void delete(ID idEntity);

        E findOne(ID idEntity);

        IEnumerable<E> findAll();
    }
}
