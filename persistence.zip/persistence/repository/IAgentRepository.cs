﻿using model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace persistence.repository
{
    public interface IAgentRepository: IRepository<string, Agent>
    {
        public Agent login(string user, string password,string job);
    }
}
