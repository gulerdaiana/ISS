﻿using Microsoft.Data.Sqlite;
using model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SQLite;
using System.Collections.Specialized;

namespace persistence.repository.dbrepository
{
    public class ProdusDBRepo:IProdusRepository
    {
        public void add(Produs entity)
        {
            SQLiteConnection connection = new SQLiteConnection("Data Source=C:/MPPDatabases/agent.db");
            connection.Open();
            var command = connection.CreateCommand();
            command.CommandText = @"insert into Produse (id,denumire,pret,cantitate) values ($id, $denumire, $pret, $cantitate)";
            command.Parameters.AddWithValue("$id", entity.Id);
            command.Parameters.AddWithValue("$denumire", entity.denumire);
            command.Parameters.AddWithValue("$pret", entity.pret);
            command.Parameters.AddWithValue("$cantitate", entity.cantitate);
            var reader = command.ExecuteReader();

        }

        public void delete(long idEntity)
        {
            SQLiteConnection connection = new SQLiteConnection("Data Source=C:/MPPDatabases/agent.db");
            connection.Open();
            var command = connection.CreateCommand();
            command.CommandText = @"delete from Produse where id=$id";
            command.Parameters.AddWithValue("$id", idEntity);
            var reader = command.ExecuteReader();   
        }
        public void update(long id, string denumire, int pret,int cantitate)
        {
            SQLiteConnection connection = new SQLiteConnection("Data Source=C:/MPPDatabases/agent.db");
            connection.Open();

            Produs produs = findOne(id);

            var command = connection.CreateCommand();
            command.CommandText = @"update Produse Set denumire=$denumire,pret=$pret,cantitate=$cantitate where id=$id";
            command.Parameters.AddWithValue("$denumire", denumire);
            command.Parameters.AddWithValue("$pret", pret);
            command.Parameters.AddWithValue("$cantitate", cantitate);
            command.Parameters.AddWithValue("$id", id);
            var reader = command.ExecuteReader();
        }
        public IEnumerable<Produs> findAll()
        {
            SQLiteConnection connection = new SQLiteConnection("Data Source=C:/MPPDatabases/agent.db");
            connection.Open();

            var command = connection.CreateCommand();
            command.CommandText = @"SELECT * FROM Produse";
            List<Produs> produse = new List<Produs>();
            Produs produs = null;
            using (var reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    var id = reader.GetInt16(0);
                    var denumire = reader.GetString(1);
                    var pret = reader.GetInt16(2);
                    var cantitate = reader.GetInt16(3);
                    produs = new Produs(id, denumire,pret,cantitate);
                    produse.Add(produs);
                }
            }
            return produse;
        }

        public Produs findOne(long idEntity)
        {
            SQLiteConnection connection = new SQLiteConnection("Data Source=C:/MPPDatabases/agent.db");
            connection.Open();
            var command = connection.CreateCommand();
            command.CommandText = @"select * from Produse where id = $id";
            command.Parameters.AddWithValue("$id", idEntity);
            Produs produs = null;
            using (var reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    var denumire = reader.GetString(1);
                    var pret = reader.GetInt16(2);
                    var cantitate = reader.GetInt16(3);

                    produs = new Produs(idEntity, denumire,pret,cantitate);
                }
            }
            return produs;
        }

        public void update(long id, int cantitate)
        {
            SQLiteConnection connection = new SQLiteConnection("Data Source=C:/MPPDatabases/agent.db");
            connection.Open();

            Produs produs = findOne(id);

            var command = connection.CreateCommand();
            command.CommandText = @"update Produse Set cantitate=$cantitate where id=$id";
            command.Parameters.AddWithValue("$cantitate", cantitate + produs.cantitate);
            command.Parameters.AddWithValue("$id", id);
            var reader = command.ExecuteReader();
        }
    }
}
