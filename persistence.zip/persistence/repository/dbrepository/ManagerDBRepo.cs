﻿using Microsoft.Data.Sqlite;
using model;
using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace persistence.repository.dbrepository
{
    public class ManagerDBRepo:IManagerRepository
    {
        public void add(Manager entity)
        {
            throw new NotImplementedException();
        }

        public void delete(string idEntity)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Manager> findAll()
        {
            throw new NotImplementedException();
        }

        public Manager findOne(string idEntity)
        {
            SQLiteConnection connection = new SQLiteConnection("Data Source=C:/MPPDatabases/agent.db");
            connection.Open();
            var command = connection.CreateCommand();
            command.CommandText = @"SELECT * FROM Manageri WHERE username = $username";
            command.Parameters.AddWithValue("$username", idEntity);
            Manager manager = null;
            using (var reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    var parola = reader.GetString(1);
                    var job = reader.GetString(2);
                    manager = new Manager(idEntity, parola, job);
                }
            }
            return manager;
        }

        public Manager login(string user, string password, string job)
        {
            if (findOne(user).password == password && findOne(user).job == job)
                return findOne(user);
            else
                return null;
        }
    }
}
