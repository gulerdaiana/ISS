﻿using Microsoft.Data.Sqlite;
using model;
using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace persistence.repository.dbrepository
{
    public class AgentDBRepo: IAgentRepository
    {
        public void add(Agent entity)
        {
            throw new NotImplementedException();
        }

        public void delete(string idEntity)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Agent> findAll()
        {
            throw new NotImplementedException();
        }

        public Agent findOne(string idEntity)
        {
            SQLiteConnection connection = new SQLiteConnection("Data Source=C:/MPPDatabases/agent.db");
            connection.Open();
            var command = connection.CreateCommand();
            command.CommandText = @"SELECT * FROM Agenti WHERE username = $username";
            command.Parameters.AddWithValue("$username", idEntity);
            Agent agent = null;
            using (var reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    var parola = reader.GetString(1);
                    var job=reader.GetString(2);
                    agent = new Agent(idEntity, parola,job);
                }
            }
            return agent;
        }

        public Agent login(string user, string password,string job)
        {
            if (findOne(user).password == password && findOne(user).job == job)
                return findOne(user);
            else
                return null;
        }
    }

}
