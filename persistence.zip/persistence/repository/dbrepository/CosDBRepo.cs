﻿using model;
using System.Data.SQLite;

namespace persistence.repository.dbrepository
{
    public class CosDBRepo
    {
        public void add(Cos entity)
        { if (entity.produs.cantitate == 0)
                throw new Exception("Nu mai exista produse in stoc!");
            SQLiteConnection connection = new SQLiteConnection("Data Source=C:/MPPDatabases/agent.db");
            connection.Open();
            var command = connection.CreateCommand();
            command.CommandText = @"insert into Cos (idProdus,denumire,pret) values ($idProdus,$denumire,$pret)";
            command.Parameters.AddWithValue("$idProdus", entity.produs.Id);
            command.Parameters.AddWithValue("$denumire", entity.produs.denumire);
            command.Parameters.AddWithValue("$pret", entity.produs.pret);
            entity.produs.cantitate--;
            entity.total = entity.total + entity.produs.pret;
            var reader = command.ExecuteReader();
            Console.WriteLine("Produsul a fost adaugat in cos!");

        }

    }
}
