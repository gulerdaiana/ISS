﻿using model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace persistence.repository
{
    public interface IManagerRepository: IRepository<string, Manager>
    {
        public Manager login(string user, string password, string job);
    }
}
