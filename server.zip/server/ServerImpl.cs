﻿using model;
using persistence.repository;
using persistence.repository.dbrepository;
using services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace server
{
    public class ServerImpl: IService
    {
        private IAgentRepository agentRepository;
        private IManagerRepository managerRepository;
        private IProdusRepository produsRepository;
        private CosDBRepo cosRepository;
        private readonly IList<IObserver> loggedClients;

        public ServerImpl(IAgentRepository agentRepository, IManagerRepository managerRepository, IProdusRepository produsRepository,CosDBRepo cosRepository)
        {
            this.agentRepository = agentRepository;
            this.managerRepository = managerRepository;
            this.produsRepository = produsRepository;
            this.cosRepository = cosRepository;
            this.loggedClients = new List<IObserver>();
        }

        public Agent loginAgent(String user, String password, String job, IObserver client)
        {
            Agent a = agentRepository.login(user, password,job);

            if (a == null)
                throw new Exception("Date login incorecte");

            loggedClients.Add(client);



            return a;
        }
        public IEnumerable<Produs> getAllProduse()
        {
            return produsRepository.findAll();
        }

        public Agent findOneAgent(string username)
        {
            return agentRepository.findOne(username);
        }
        public Manager findOneManager(string username)
        {
            return managerRepository.findOne(username);
        }
        public Produs findOneProdus(long id)
        {
            return produsRepository.findOne(id);
        }
       
        public void addInCos(Cos c)
        {
            cosRepository.add(c);
        }

        /*public void add(Produs produs)
        {
            produsRepository.add(produs);
            //this.notifyDonatie(produsRepository.findOne(produs.Id));
        }
        public void delete(long id)
        {
            produsRepository.delete(id);
        }
        public void update(long id, string denumire, int pret, int cantitate)
        {
            produsRepository.update(id, denumire, pret, cantitate);
        }*/
        public void notifyDonatie(Produs p)
        {
            IEnumerable<Produs> all = getAllProduse();
            try
            {
                foreach (IObserver obs in loggedClients)
                {
                    Console.WriteLine("Notifying : " + obs.ToString());
                    Task.Run(() => obs.ProdusAdaugat(all, p));
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message + "[NotifyInscriere]");
            }
        }

        public Manager loginManager(string user, string password, string job, IObserver client)
        {
            Manager m = managerRepository.login(user, password, job);

            if (m == null)
                throw new Exception("Date login incorecte");

            loggedClients.Add(client);



            return m;
        }
    }
}
