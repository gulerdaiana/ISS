﻿using log4net;
using networking.objectProtocol;
using networking.servers;
using persistence.repository.dbrepository;
using services;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace server
{


    static class StartObjectServer
    {
        static void Main(string[] args)
        {
            String connectionString = "Data Source=D:\\MPPDatabases\\agent.db";

          
            Console.WriteLine("Configuration Settings for agentDB {0}", GetConnectionStringByName("agentDB"));
            IDictionary<String, string> props = new SortedList<String, String>();

            props.Add("ConnectionString", GetConnectionStringByName("agentDB"));


            AgentDBRepo agentRepo = new AgentDBRepo();
            ManagerDBRepo managerRepo = new ManagerDBRepo();
            ProdusDBRepo produsRepo = new ProdusDBRepo();
            CosDBRepo cosRepo = new CosDBRepo();

            IService serviceImpl = new ServerImpl(agentRepo, managerRepo, produsRepo,cosRepo);
            SerialServer server = new SerialServer("127.0.0.1", 55556, serviceImpl);
            server.Start();
            Debug.WriteLine("Server started ....");

        }

        static string GetConnectionStringByName(string name)
        {
            string returnValue = null;

            ConnectionStringSettings settings = ConfigurationManager.ConnectionStrings[name];

            if (settings != null)
                returnValue = settings.ConnectionString;

            return returnValue;
        }



    }
    
    public class SerialServer : ConcurrentServer
    {
        private IService server;
        private ClientObjectWorker worker;

        public SerialServer(string host, int port, IService server) : base(host, port)
        {
            this.server = server;

        }

        protected override Thread createWorker(TcpClient client)
        {
            worker = new ClientObjectWorker(server, client);
            Debug.WriteLine("Client Connected .. ");
            return new Thread(new ThreadStart(worker.run));
        }
    }


}
