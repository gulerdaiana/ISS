﻿using model;
using persistence.repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace server
{
    public class ServiceManager
    {
        public IProdusRepository produsRepository;

        public ServiceManager(IProdusRepository produsRepository)
        {
            this.produsRepository = produsRepository;
        }


        public void add(Produs produs)
        {
            produsRepository.add(produs);
            //this.notifyDonatie(produsRepository.findOne(produs.Id));
        }
        public void delete(long id)
        {
            produsRepository.delete(id);
        }
        public void update(long id, string denumire, int pret, int cantitate)
        {
            produsRepository.update(id, denumire, pret, cantitate);
        }
    }
}
