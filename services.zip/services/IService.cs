﻿using model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace services
{
    public interface IService
    {
      
        public Agent loginAgent(String user, String password,String job, IObserver client);
        public Manager loginManager(String user, String password, String job, IObserver client);
        public IEnumerable<Produs> getAllProduse();

        public Produs findOneProdus(long id);
        public Agent findOneAgent(string username);
        public Manager findOneManager(string username);

        public void addInCos(Cos c);

        //public void add(Produs produs);
        //public void delete(long id);
        //public void update(long id, string denumire, int pret, int cantitate);
    }
}
