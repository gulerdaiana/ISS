﻿using model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace services
{
    public interface IObserver
    {
        void ProdusAdaugat(IEnumerable<Produs> all, Produs p);
        //void ProdusSters(IEnumerable<Produs> all,long id);
       // void ProdusModificat(IEnumerable<Produs> all, Produs p);
    }
}
