﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace model
{
    [Serializable]
    public class Produs:Entity<long>
    {
        public string denumire { get; set; }
        public int pret { get; set; }

        public int cantitate { get; set; }

        public Produs(long aLong, string denumire, int pret, int cantitate):base(aLong)
        {
            this.denumire = denumire;
            this.pret = pret;
            this.cantitate = cantitate;
        }
    }
}
