﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace model
{
    [Serializable]
    public class Cos
    {
        public Produs produs {  get; set; } 
        public int total { get; set; }

        public Cos(Produs produs, int total)
        {
            this.produs = produs;
            this.total = total;
        }

    }
}
