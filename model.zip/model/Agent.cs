﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace model
{
    [Serializable]
    public class Agent: Entity<string>
    {
        public string password { get; set; }

        public string job { get; set; }

        public Agent(string id, string pass, string job) : base(id)
        {
            this.password = pass;
            this.job = job;
        }
    }
}
