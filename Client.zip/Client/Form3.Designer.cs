﻿namespace Client
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridProduse = new DataGridView();
            label1 = new Label();
            textBoxDenumire = new TextBox();
            textBoxPret = new TextBox();
            label2 = new Label();
            buttonUpdate = new Button();
            label3 = new Label();
            label4 = new Label();
            textBoxCantitate = new TextBox();
            buttonAdauga = new Button();
            buttonSterge = new Button();
            label5 = new Label();
            textBoxId = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dataGridProduse).BeginInit();
            SuspendLayout();
            // 
            // dataGridProduse
            // 
            dataGridProduse.AllowUserToAddRows = false;
            dataGridProduse.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridProduse.BackgroundColor = SystemColors.ButtonHighlight;
            dataGridProduse.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridProduse.Location = new Point(367, 127);
            dataGridProduse.Margin = new Padding(6);
            dataGridProduse.Name = "dataGridProduse";
            dataGridProduse.RowHeadersVisible = false;
            dataGridProduse.RowHeadersWidth = 82;
            dataGridProduse.RowTemplate.Height = 25;
            dataGridProduse.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridProduse.Size = new Size(908, 469);
            dataGridProduse.TabIndex = 14;
            dataGridProduse.CellClick += ProdusClicked;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10.875F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label1.Location = new Point(593, 617);
            label1.Margin = new Padding(6, 0, 6, 0);
            label1.Name = "label1";
            label1.Size = new Size(150, 40);
            label1.TabIndex = 16;
            label1.Text = "Denumire";
            // 
            // textBoxDenumire
            // 
            textBoxDenumire.Location = new Point(593, 674);
            textBoxDenumire.Margin = new Padding(6);
            textBoxDenumire.Name = "textBoxDenumire";
            textBoxDenumire.Size = new Size(209, 39);
            textBoxDenumire.TabIndex = 17;
            // 
            // textBoxPret
            // 
            textBoxPret.Location = new Point(863, 674);
            textBoxPret.Margin = new Padding(6);
            textBoxPret.Name = "textBoxPret";
            textBoxPret.Size = new Size(159, 39);
            textBoxPret.TabIndex = 19;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10.875F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label2.Location = new Point(863, 617);
            label2.Margin = new Padding(6, 0, 6, 0);
            label2.Name = "label2";
            label2.Size = new Size(73, 40);
            label2.TabIndex = 18;
            label2.Text = "Pret";
            // 
            // buttonUpdate
            // 
            buttonUpdate.BackColor = Color.Plum;
            buttonUpdate.Font = new Font("Segoe UI", 10.875F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            buttonUpdate.Location = new Point(987, 761);
            buttonUpdate.Margin = new Padding(6);
            buttonUpdate.Name = "buttonUpdate";
            buttonUpdate.Size = new Size(241, 61);
            buttonUpdate.TabIndex = 28;
            buttonUpdate.Text = "Update produs";
            buttonUpdate.UseVisualStyleBackColor = false;
            buttonUpdate.Click += buttonUpdate_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Black", 13.875F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label3.Location = new Point(758, 54);
            label3.Name = "label3";
            label3.Size = new Size(169, 50);
            label3.TabIndex = 29;
            label3.Text = "Produse";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 10.875F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label4.Location = new Point(1101, 617);
            label4.Margin = new Padding(6, 0, 6, 0);
            label4.Name = "label4";
            label4.Size = new Size(143, 40);
            label4.TabIndex = 30;
            label4.Text = "Cantitate";
            label4.Click += label4_Click;
            // 
            // textBoxCantitate
            // 
            textBoxCantitate.Location = new Point(1101, 674);
            textBoxCantitate.Margin = new Padding(6);
            textBoxCantitate.Name = "textBoxCantitate";
            textBoxCantitate.Size = new Size(174, 39);
            textBoxCantitate.TabIndex = 31;
            // 
            // buttonAdauga
            // 
            buttonAdauga.BackColor = Color.Plum;
            buttonAdauga.Font = new Font("Segoe UI", 10.875F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            buttonAdauga.Location = new Point(367, 761);
            buttonAdauga.Margin = new Padding(6);
            buttonAdauga.Name = "buttonAdauga";
            buttonAdauga.Size = new Size(241, 61);
            buttonAdauga.TabIndex = 32;
            buttonAdauga.Text = "Adauga produs";
            buttonAdauga.UseVisualStyleBackColor = false;
            buttonAdauga.Click += buttonAdauga_Click_1;
            // 
            // buttonSterge
            // 
            buttonSterge.BackColor = Color.Plum;
            buttonSterge.Font = new Font("Segoe UI", 10.875F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            buttonSterge.Location = new Point(676, 761);
            buttonSterge.Margin = new Padding(6);
            buttonSterge.Name = "buttonSterge";
            buttonSterge.Size = new Size(241, 61);
            buttonSterge.TabIndex = 33;
            buttonSterge.Text = "Sterge produs";
            buttonSterge.UseVisualStyleBackColor = false;
            buttonSterge.Click += buttonSterge_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 10.875F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label5.Location = new Point(383, 617);
            label5.Margin = new Padding(6, 0, 6, 0);
            label5.Name = "label5";
            label5.Size = new Size(43, 40);
            label5.TabIndex = 34;
            label5.Text = "Id";
            // 
            // textBoxId
            // 
            textBoxId.Location = new Point(383, 674);
            textBoxId.Margin = new Padding(6);
            textBoxId.Name = "textBoxId";
            textBoxId.Size = new Size(144, 39);
            textBoxId.TabIndex = 35;
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.PapayaWhip;
            ClientSize = new Size(1616, 881);
            Controls.Add(textBoxId);
            Controls.Add(label5);
            Controls.Add(buttonSterge);
            Controls.Add(buttonAdauga);
            Controls.Add(textBoxCantitate);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(buttonUpdate);
            Controls.Add(textBoxPret);
            Controls.Add(label2);
            Controls.Add(textBoxDenumire);
            Controls.Add(label1);
            Controls.Add(dataGridProduse);
            Margin = new Padding(6);
            Name = "Form3";
            Text = "Form3";
            Load += Form2_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridProduse).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridProduse;
        private Label label1;
        private TextBox textBoxDenumire;
        private TextBox textBoxPret;
        private Label label2;
        private Button buttonUpdate;
        private Label label3;
        private Label label4;
        private TextBox textBoxCantitate;
        private Button buttonAdauga;
        private Button buttonSterge;
        private Label label5;
        private TextBox textBoxId;
    }
}