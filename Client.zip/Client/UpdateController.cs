﻿using model;
using services;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client
{
    public class UpdateController : IObserver
    {
        public event EventHandler<UpdateEventArgs> updateEvent;
        private readonly IService server;
        private Agent currentUser1;
        private Manager currentUser2;

        public UpdateController(IService server, Agent currentUser1,Manager currentUser2)
        {
            this.server=server;
            this.currentUser1=currentUser1;
            this.currentUser2 = currentUser2;
        }


        protected void OnEvent(UpdateEventArgs args)
        {
            if (updateEvent == null) return;
                updateEvent(this, args);
            Debug.WriteLine("Update Event called");
        }

        public void ProdusAdaugat(IEnumerable<Produs> all, Produs p)
        {
            Debug.WriteLine("Produs Update Controller");
            UpdateEventArgs args = new UpdateEventArgs(new object[] { all, p });
            OnEvent(args);
        }
    }
}
