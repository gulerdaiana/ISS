﻿namespace Client
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridProduse = new DataGridView();
            dataGridCos = new DataGridView();
            Id = new DataGridViewTextBoxColumn();
            Denumire = new DataGridViewTextBoxColumn();
            Pret = new DataGridViewTextBoxColumn();
            label1 = new Label();
            textBoxDenumire = new TextBox();
            textBoxPret = new TextBox();
            label2 = new Label();
            buttonDoneaza = new Button();
            buttonPlaseaza = new Button();
            label3 = new Label();
            textBoxId = new TextBox();
            Produse = new Label();
            label4 = new Label();
            Total = new Label();
            textBoxTotal = new TextBox();
            label5 = new Label();
            textBoxCantitate = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dataGridProduse).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridCos).BeginInit();
            SuspendLayout();
            // 
            // dataGridProduse
            // 
            dataGridProduse.AllowUserToAddRows = false;
            dataGridProduse.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridProduse.BackgroundColor = SystemColors.ButtonHighlight;
            dataGridProduse.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridProduse.Location = new Point(79, 151);
            dataGridProduse.Margin = new Padding(6);
            dataGridProduse.Name = "dataGridProduse";
            dataGridProduse.RowHeadersVisible = false;
            dataGridProduse.RowHeadersWidth = 82;
            dataGridProduse.RowTemplate.Height = 25;
            dataGridProduse.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridProduse.Size = new Size(656, 469);
            dataGridProduse.TabIndex = 14;
            dataGridProduse.CellClick += ProdusClicked;
            // 
            // dataGridCos
            // 
            dataGridCos.AllowUserToAddRows = false;
            dataGridCos.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridCos.BackgroundColor = SystemColors.ButtonHighlight;
            dataGridCos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridCos.Columns.AddRange(new DataGridViewColumn[] { Id, Denumire, Pret });
            dataGridCos.Location = new Point(856, 151);
            dataGridCos.Margin = new Padding(6);
            dataGridCos.Name = "dataGridCos";
            dataGridCos.RowHeadersVisible = false;
            dataGridCos.RowHeadersWidth = 82;
            dataGridCos.RowTemplate.Height = 25;
            dataGridCos.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridCos.Size = new Size(680, 469);
            dataGridCos.TabIndex = 15;
            dataGridCos.CellContentClick += dataGridCos_CellContentClick;
            // 
            // Id
            // 
            Id.HeaderText = "Id";
            Id.MinimumWidth = 10;
            Id.Name = "Id";
            // 
            // Denumire
            // 
            Denumire.HeaderText = "Denumire";
            Denumire.MinimumWidth = 10;
            Denumire.Name = "Denumire";
            // 
            // Pret
            // 
            Pret.HeaderText = "Pret";
            Pret.MinimumWidth = 10;
            Pret.Name = "Pret";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Black", 10.125F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label1.Location = new Point(195, 636);
            label1.Margin = new Padding(6, 0, 6, 0);
            label1.Name = "label1";
            label1.Size = new Size(148, 37);
            label1.TabIndex = 16;
            label1.Text = "Denumire";
            // 
            // textBoxDenumire
            // 
            textBoxDenumire.Location = new Point(195, 679);
            textBoxDenumire.Margin = new Padding(6);
            textBoxDenumire.Name = "textBoxDenumire";
            textBoxDenumire.Size = new Size(174, 39);
            textBoxDenumire.TabIndex = 17;
            // 
            // textBoxPret
            // 
            textBoxPret.Location = new Point(397, 679);
            textBoxPret.Margin = new Padding(6);
            textBoxPret.Name = "textBoxPret";
            textBoxPret.Size = new Size(119, 39);
            textBoxPret.TabIndex = 19;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Black", 10.125F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label2.Location = new Point(397, 637);
            label2.Margin = new Padding(6, 0, 6, 0);
            label2.Name = "label2";
            label2.Size = new Size(73, 37);
            label2.TabIndex = 18;
            label2.Text = "Pret";
            // 
            // buttonDoneaza
            // 
            buttonDoneaza.BackColor = Color.Plum;
            buttonDoneaza.Font = new Font("Segoe UI", 10.875F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            buttonDoneaza.Location = new Point(105, 760);
            buttonDoneaza.Margin = new Padding(6);
            buttonDoneaza.Name = "buttonDoneaza";
            buttonDoneaza.Size = new Size(278, 87);
            buttonDoneaza.TabIndex = 28;
            buttonDoneaza.Text = "Adauga in cos";
            buttonDoneaza.UseVisualStyleBackColor = false;
            buttonDoneaza.Click += buttonAdauga_Click;
            // 
            // buttonPlaseaza
            // 
            buttonPlaseaza.BackColor = Color.Plum;
            buttonPlaseaza.Font = new Font("Segoe UI", 10.875F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            buttonPlaseaza.Location = new Point(1059, 752);
            buttonPlaseaza.Margin = new Padding(6);
            buttonPlaseaza.Name = "buttonPlaseaza";
            buttonPlaseaza.Size = new Size(317, 95);
            buttonPlaseaza.TabIndex = 29;
            buttonPlaseaza.Text = "Plaseaza comanda";
            buttonPlaseaza.UseVisualStyleBackColor = false;
            buttonPlaseaza.Click += buttonPlaseaza_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Black", 10.125F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label3.Location = new Point(116, 636);
            label3.Name = "label3";
            label3.Size = new Size(43, 37);
            label3.TabIndex = 30;
            label3.Text = "Id";
            // 
            // textBoxId
            // 
            textBoxId.Location = new Point(105, 679);
            textBoxId.Margin = new Padding(6);
            textBoxId.Name = "textBoxId";
            textBoxId.Size = new Size(72, 39);
            textBoxId.TabIndex = 31;
            // 
            // Produse
            // 
            Produse.AutoSize = true;
            Produse.Font = new Font("Segoe UI Black", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            Produse.Location = new Point(324, 74);
            Produse.Name = "Produse";
            Produse.Size = new Size(146, 45);
            Produse.TabIndex = 32;
            Produse.Text = "Produse";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Black", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label4.Location = new Point(1059, 74);
            label4.Name = "label4";
            label4.Size = new Size(325, 45);
            label4.TabIndex = 33;
            label4.Text = "Cos de cumparaturi";
            // 
            // Total
            // 
            Total.AutoSize = true;
            Total.Font = new Font("Segoe UI Black", 10.875F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            Total.Location = new Point(870, 637);
            Total.Name = "Total";
            Total.Size = new Size(91, 40);
            Total.TabIndex = 34;
            Total.Text = "Total";
            // 
            // textBoxTotal
            // 
            textBoxTotal.Location = new Point(870, 679);
            textBoxTotal.Margin = new Padding(6);
            textBoxTotal.Name = "textBoxTotal";
            textBoxTotal.Size = new Size(167, 39);
            textBoxTotal.TabIndex = 35;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI Black", 10.125F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label5.Location = new Point(561, 634);
            label5.Margin = new Padding(6, 0, 6, 0);
            label5.Name = "label5";
            label5.Size = new Size(141, 37);
            label5.TabIndex = 36;
            label5.Text = "Cantitate";
            label5.Click += label5_Click_1;
            // 
            // textBoxCantitate
            // 
            textBoxCantitate.Location = new Point(561, 680);
            textBoxCantitate.Margin = new Padding(6);
            textBoxCantitate.Name = "textBoxCantitate";
            textBoxCantitate.Size = new Size(174, 39);
            textBoxCantitate.TabIndex = 37;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.PapayaWhip;
            ClientSize = new Size(1616, 881);
            Controls.Add(textBoxCantitate);
            Controls.Add(label5);
            Controls.Add(textBoxTotal);
            Controls.Add(Total);
            Controls.Add(label4);
            Controls.Add(Produse);
            Controls.Add(textBoxId);
            Controls.Add(label3);
            Controls.Add(buttonPlaseaza);
            Controls.Add(buttonDoneaza);
            Controls.Add(textBoxPret);
            Controls.Add(label2);
            Controls.Add(textBoxDenumire);
            Controls.Add(label1);
            Controls.Add(dataGridCos);
            Controls.Add(dataGridProduse);
            Margin = new Padding(6);
            Name = "Form2";
            Text = "Form2";
            Load += Form2_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridProduse).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridCos).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridProduse;
        private DataGridView dataGridCos;
        private Label label1;
        private TextBox textBoxDenumire;
        private TextBox textBoxPret;
        private Label label2;
        private Button buttonDoneaza;
        private Button buttonPlaseaza;
        private Label label3;
        private TextBox textBoxId;
        private Label Produse;
        private Label label4;
        private DataGridViewTextBoxColumn Id;
        private DataGridViewTextBoxColumn Denumire;
        private DataGridViewTextBoxColumn Pret;
        private Label Total;
        private TextBox textBoxTotal;
        private Label label5;
        private TextBox textBoxCantitate;
    }
}