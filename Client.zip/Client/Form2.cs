﻿using services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using model;
using persistence.repository;

namespace Client
{
    public partial class Form2 : Form, IObserver
    {
        int total = 0;
        private IService Service { get; set; }
        public Agent CurrentUser { get; set; }

        private UpdateController ctrl;
        public Form2(IService service, Agent a, UpdateController c)
        {
            Service = service;
            CurrentUser = a;
            this.ctrl = c;
            InitializeComponent();
            //dataGridCazuri.DataSource = Service.getAllCazuri();
            //dataGridDonatori.DataSource = Service.getAllDonatori();

        }
        public delegate void UpdateGridViewCallback(DataGridView d1, IEnumerable<Produs> list);
        public void update(object sender, UpdateEventArgs args)
        {

            Debug.WriteLine("Updating produse in UI");
            dataGridProduse.BeginInvoke(new UpdateGridViewCallback(this.UpdateGridView), new object[] { dataGridProduse, (IEnumerable<Produs>)args.Data[0] });

        }
        public void UpdateGridView(DataGridView d1, IEnumerable<Produs> list)
        {
            Debug.WriteLine("UPDATEGRIDVIEW");
            d1.DataSource = null;
            d1.DataSource = list;
        }
        public void setInitialData()
        {
            dataGridProduse.DataSource = Service.getAllProduse();
            this.ctrl.updateEvent += update;
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        /* private void buttonDoneaza_Click(object sender, EventArgs e)
         {
             long idC = long.Parse(textBoxDenumire.Text);
             long idD = long.Parse(textBoxPret.Text);
             int suma = int.Parse(textBoxSuma.Text);
             textBoxNume.Clear();
             textBoxDenumire.Clear();
             textBoxPret.Clear();
             textBoxSuma.Clear();
             textBoxAdresa.Clear();
             textBoxTelefon.Clear();
             Service.doneaza(idC, idD, suma);


         private void DonatorClicked(object sender, DataGridViewCellEventArgs e)
         {
             string nume = (string)dataGridCos.SelectedRows[0].Cells[0].Value;
             string adresa = (string)dataGridCos.SelectedRows[0].Cells[1].Value;
             string telefon = (string)dataGridCos.SelectedRows[0].Cells[2].Value;
             long idD = (long)dataGridCos.SelectedRows[0].Cells[3].Value;

             textBoxNume.Text = nume;
             textBoxAdresa.Text = adresa;
             textBoxPret.Text = idD.ToString();
             textBoxTelefon.Text = telefon;
         } }*/

        private void CazClicked(object sender, DataGridViewCellEventArgs e)
        {
            long idC = (long)dataGridProduse.SelectedRows[0].Cells[2].Value;
            textBoxDenumire.Text = idC.ToString();
        }

        public void ProdusAdaugat(IEnumerable<Produs> all, Produs p)
        {
            throw new NotImplementedException();
        }

        private void buttonAdauga_Click(object sender, EventArgs e)
        {
            int id = int.Parse(textBoxId.Text);
            string denumire = textBoxDenumire.Text;
            int pret = int.Parse(textBoxPret.Text);
            int cantitate = int.Parse(textBoxCantitate.Text);
            
            dataGridCos.Rows.Add(id, denumire, pret);
            dataGridCos.Refresh();
            total=total+pret;
            textBoxId.Clear();
            textBoxDenumire.Clear();
            textBoxPret.Clear();
            textBoxCantitate.Clear();
            textBoxTotal.Text = total.ToString();

            MessageBox.Show("Produs adaugat cu succes!");
            //dataGridProduse.DataSource = Service.getAllProduse();
            //Service.doneaza(idC, idD, suma);
        }

        private void ProdusClicked(object sender, DataGridViewCellEventArgs e)
        {
            long id = (long)dataGridProduse.SelectedRows[0].Cells[3].Value;
            textBoxId.Text = id.ToString();
            string denumire = (string)dataGridProduse.SelectedRows[0].Cells[0].Value;
            textBoxDenumire.Text = denumire;
            int pret = (int)dataGridProduse.SelectedRows[0].Cells[1].Value;
            textBoxPret.Text = pret.ToString();
            int cantitate = (int)dataGridProduse.SelectedRows[0].Cells[2].Value;
            textBoxCantitate.Text = cantitate.ToString();
        }

        private void buttonPlaseaza_Click(object sender, EventArgs e)
        {
            dataGridCos.Rows.Clear();
            //dataGridCos.Columns.Clear();
            dataGridCos.Refresh();
            MessageBox.Show("Comanda plasata cu succes!");
            textBoxTotal.Clear();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void dataGridCos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label5_Click_1(object sender, EventArgs e)
        {

        }
    }
}
