﻿namespace Client
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label2 = new Label();
            label1 = new Label();
            buttonLogin = new Button();
            textBoxParola = new TextBox();
            textBoxUsername = new TextBox();
            label3 = new Label();
            textBoxJob = new TextBox();
            SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Black", 10.875F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label2.Location = new Point(251, 265);
            label2.Margin = new Padding(6, 0, 6, 0);
            label2.Name = "label2";
            label2.Size = new Size(156, 40);
            label2.TabIndex = 14;
            label2.Text = "Password";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Black", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label1.Location = new Point(251, 156);
            label1.Margin = new Padding(6, 0, 6, 0);
            label1.Name = "label1";
            label1.Size = new Size(177, 45);
            label1.TabIndex = 13;
            label1.Text = "Username";
            // 
            // buttonLogin
            // 
            buttonLogin.BackColor = Color.Plum;
            buttonLogin.Font = new Font("Segoe UI", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            buttonLogin.Location = new Point(505, 453);
            buttonLogin.Margin = new Padding(6);
            buttonLogin.Name = "buttonLogin";
            buttonLogin.Size = new Size(193, 79);
            buttonLogin.TabIndex = 12;
            buttonLogin.Text = "LOG IN";
            buttonLogin.UseVisualStyleBackColor = false;
            buttonLogin.Click += buttonLogin_Click;
            // 
            // textBoxParola
            // 
            textBoxParola.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            textBoxParola.Location = new Point(440, 265);
            textBoxParola.Margin = new Padding(6);
            textBoxParola.Name = "textBoxParola";
            textBoxParola.PasswordChar = '*';
            textBoxParola.Size = new Size(331, 50);
            textBoxParola.TabIndex = 11;
            // 
            // textBoxUsername
            // 
            textBoxUsername.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            textBoxUsername.Location = new Point(440, 156);
            textBoxUsername.Margin = new Padding(6);
            textBoxUsername.Name = "textBoxUsername";
            textBoxUsername.Size = new Size(331, 50);
            textBoxUsername.TabIndex = 10;
            textBoxUsername.TextChanged += textBoxUsername_TextChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Black", 10.875F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label3.Location = new Point(291, 365);
            label3.Margin = new Padding(6, 0, 6, 0);
            label3.Name = "label3";
            label3.Size = new Size(68, 40);
            label3.TabIndex = 15;
            label3.Text = "Job";
            label3.Click += label3_Click;
            // 
            // textBoxJob
            // 
            textBoxJob.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            textBoxJob.Location = new Point(440, 358);
            textBoxJob.Margin = new Padding(6);
            textBoxJob.Name = "textBoxJob";
            textBoxJob.Size = new Size(331, 50);
            textBoxJob.TabIndex = 16;
            textBoxJob.TextChanged += textBox1_TextChanged;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.PapayaWhip;
            ClientSize = new Size(1205, 599);
            Controls.Add(textBoxJob);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(buttonLogin);
            Controls.Add(textBoxParola);
            Controls.Add(textBoxUsername);
            Margin = new Padding(6);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label2;
        private Label label1;
        private Button buttonLogin;
        private TextBox textBoxParola;
        private TextBox textBoxUsername;
        private Label label3;
        private TextBox textBoxJob;
    }
}