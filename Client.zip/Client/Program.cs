using networking.objectProtocol;
using persistence.repository;
using persistence.repository.dbrepository;
using server;
using services;
using System.Windows.Forms.Design;

namespace Client
{
    static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            IProdusRepository repo = new ProdusDBRepo();
            IService service = new ServicesObjectProxy("127.0.0.1", 55556);
            ServiceManager s = new ServiceManager(repo);
            ApplicationConfiguration.Initialize();
            Application.Run(new Form1(service,s));

        }
    }
}