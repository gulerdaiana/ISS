using Client;
using persistence.repository;
using server;
using services;
using System;
using System.Diagnostics;
using System.Threading;
using System.Windows.Forms;

namespace Client
{
    public partial class Form1 : Form
    {
        private IService Service { get; set; }
        ServiceManager ServiceManager { get; set; }
        public Form1(IService service, ServiceManager serviceManager)
        {
            Service = service;
            InitializeComponent();
            ServiceManager = serviceManager;
        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            //MessageBox.Show("You clicked login :)");
            string data = this.textBoxUsername.Text;
            string password = this.textBoxParola.Text;
            string job = this.textBoxJob.Text;
            this.textBoxUsername.Clear();
            this.textBoxParola.Clear();
            this.textBoxJob.Clear();


            try
            {
                UpdateController ctrl = new UpdateController(Service, null, null);
                // Service.login(data, password, ctrl);
                Form2 f2 = new Form2(Service, null, ctrl);
                //Form3 f3 = new Form3(Service, null, ctrl);
                f2.CurrentUser = Service.loginAgent(data, password, job, ctrl);
                //f3.CurrentUser = Service.loginManager(data, password, job, ctrl);
                Thread t = new Thread(() =>
                {
                    Debug.WriteLine(f2.CurrentUser);
                    //Debug.WriteLine(f3.CurrentUser);
                    Form2 f1 = new Form2(Service, f2.CurrentUser, ctrl);
                    //Form3 form = new Form3(Service, f3.CurrentUser, ctrl);
                    try
                    {
                        //Debug.WriteLine("ok");
                        f1.setInitialData();
                        Application.Run(f1);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                        throw ex;
                        return;
                    }

                }
                 );

                t.Start();

            }
            catch (Exception ex)
            {
                try
                {
                    UpdateController ctrl = new UpdateController(Service, null, null);
                    // Service.login(data, password, ctrl);
                    //Form2 f2 = new Form2(Service, null, ctrl);
                    Form3 f3 = new Form3(Service,ServiceManager, null, ctrl);
                    //f2.CurrentUser = Service.loginAgent(data, password, job, ctrl);
                    f3.CurrentUser = Service.loginManager(data, password, job, ctrl);
                    Thread t = new Thread(() =>
                    {
                        //Debug.WriteLine(f2.CurrentUser);
                        Debug.WriteLine(f3.CurrentUser);
                        //Form2 f1 = new Form2(Service, f2.CurrentUser, ctrl);
                        Form3 form = new Form3(Service,ServiceManager, f3.CurrentUser, ctrl);
                        try
                        {
                            //Debug.WriteLine("ok");
                            form.setInitialData();
                            Application.Run(form);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                            throw ex;
                            return;
                        }

                    }
                     );

                    t.Start();

                }
                catch (Exception ex1)
                {
                    MessageBox.Show(ex1.Message);
                    return;
                }
                this.Close();

            }

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxUsername_TextChanged(object sender, EventArgs e)
        {

        }
    }
}